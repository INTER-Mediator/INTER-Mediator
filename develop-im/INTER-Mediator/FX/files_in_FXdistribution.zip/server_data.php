<?php
error_reporting(E_ALL);
if (! defined('DEBUG')) {
    define('DEBUG', false);         // set to true to turn debugging on
}

if (! defined('DEBUG_FUZZY')) {
    define('DEBUG_FUZZY', false);   // set to true to activate the fuzzy debugger
}

$serverIP = '127.0.0.1';

$webCompanionPort = 80;
$dataSourceType = 'FMPro7';

$webUN = 'user';
$webPW = 'pass';

$scheme = 'http';

function fmdate( $cD, $cM, $cY ) {
	return substr( '00' . $cM, -2 ) . '/' . substr( '00' . $cD, -2 ) . '/' . $cY;
}

?>
  *
 ********************************************************************/

error_reporting(E_ALL);
if (! defined('DEBUG')) {
    define('DEBUG', true);         // set to true to turn debugging on
}
if (! defined('DEBUG_FUZZY')) {
    define('DEBUG_FUZZY', true);   // set to true to activate the fuzzy debugger
}

$serverIP = '192.168.2.3';
$webCompanionPort = 80;         // for FM 7, 8, or 9, this should we the web server port
$dataSourceType = 'FMPro9';
$webUN = 'Admin';               // defaults for Book_List in FM7; both should be blank for Book_List in FM5/6
$webPW = '';
if (strtolower($dataSourceType) == 'fmpro9') {
    $bookListFile = 'Book_List.fp7';
} else {
    $bookListFile = 'Book_List.fp5';
}
$scheme = 'http';               // generally this will be 'http'; 'https' for SSL connections to FileMaker

?>